//
//  Message.h
//  GPSTracker
//
//  Created by YS on 1/20/13.
//  Copyright (c) 2013 Yury Shubin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Attachment.h"

typedef enum
{
	MessagePriorityNormal = 0,
	MessagePriorityHigh,
	MessagePriorityOther
}MessagePriority;

@class User;

@interface TrackerMessage : NSObject<NSCoding>
{}

@property(nonatomic, readonly) NSString* messageID;
@property(nonatomic, retain) User* from;
@property(nonatomic, readonly) NSString* text;
@property(nonatomic, readonly) Attachment* attachment;
@property(nonatomic, readonly) MessagePriority priority;
@property(nonatomic, readonly) NSString* date;
@property(nonatomic) BOOL isUnread;

+(TrackerMessage*)messageWithText:(NSString*)text image:(UIImage*)image priority:(MessagePriority)priority user:(User*)user;
+(TrackerMessage*)messageWithDictionary:(NSDictionary*)dictionary;
-(NSDictionary*)dictionaryPresentation;

@end
