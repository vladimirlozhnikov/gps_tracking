//
//  Group.m
//  GPSTracker
//
//  Created by YS on 1/8/13.
//  Copyright (c) 2013 Yury Shubin. All rights reserved.
//

#import "Group.h"
#import "Model.h"
#import "Base64.h"
#import "TypeUtils.h"
#import "Pin.h"
#import "ImageUtils.h"

@interface Group()

@property(nonatomic) NSString* groupID;
@property(nonatomic) NSString* ticket;
@property(nonatomic) NSString* ownerID;
@property(nonatomic) NSMutableArray* allUsers;

@end

@implementation Group
@synthesize owner;

typedef void(^OnSuccessSimple)();
typedef void(^OnSuccess)(NSArray* users);
typedef void(^OnError)(NSString* error);

-(NSArray*)users
{
	return self.allUsers;
}

-(BOOL)isEqual:(Group*)object
{
	return [self.groupID isEqualToString:object.groupID];
}

-(BOOL)isOwner
{
	return [[Model sharedInstance].me.userID isEqualToString:self.ownerID];
}

/*-(User*)owner
{
	for(User* user in self.users)
	{
		if([user.userID isEqualToString:self.ownerID])
			return user;
	}
	return nil;
}*/

+(Group*)groupWithName:(NSString*)name description:(NSString*)description country:(Country*)country city:(City*)city
				 owner:(User*)owner isOpen:(BOOL)isOpen color:(UIColor*)color
{
	Group* group = [Group new];
	group.name = name;
	group.description = description;
	group.country = country;
	group.city = city;
	group.ownerID = owner.userID;
	group.isOpen = isOpen;
	group.color = color;
	return group;
}

-(id)initWithDictionary:(NSDictionary*)dictionary isLocally:(BOOL)isLocally
{
	if(self = [super init])
	{
//        NSLog(@"%@", dictionary);
        
		self.groupID = [dictionary objectForKey:@"groupid"];
		self.name = [dictionary objectForKey:@"name"];
		self.description = [dictionary objectForKey:@"description"];
		self.isOpen = [[dictionary objectForKey:@"is_open"] boolValue];
		self.ticket = [dictionary objectForKey:@"ticket"];
		self.email = [dictionary objectForKey:@"user_email"];
		self.firstName = [dictionary objectForKey:@"user_name"];
		self.lastName = [dictionary objectForKey:@"user_surname"];
		self.nickname = [dictionary objectForKey:@"user_nickname"];
		
		NSData* imageData = nil;
		if ([[dictionary objectForKey:@"flag"] length] > 0)
		{
			//!!! imageData = [Base64 decode:[dictionary objectForKey:@"flag"]];
		}
		else
		{
			//!!! NSString* imageUrl = [dictionary objectForKey:@"flag"];
			//!!! imageData = [NSData dataWithContentsOfURL:[NSURL URLWithString:imageUrl]];
		}
		
		if(imageData)
			self.imageFlag = [UIImage imageWithData:imageData];
		
		NSString* hexColor = [dictionary objectForKey:@"color"];
		if(hexColor)
			self.color = [Color colorWithHexString:hexColor];
		
		self.country = [Country countryWithDictionary:[dictionary objectForKey:@"country"]];
		self.city = [City cityWithDictionary:[dictionary objectForKey:@"city"]];
        User* user = [User userWithDictionary:[dictionary objectForKey:@"owner"]];
        self.owner = user;
		self.ownerID = user.userID;
	}
	return self;
}

+(Group*)groupWithDictionary:(NSDictionary*)dictionary
{
	return [[Group alloc] initWithDictionary:dictionary isLocally:NO];
}

-(NSDictionary*)dictionaryPresentation
{
	NSMutableDictionary* dictionary = [NSMutableDictionary dictionary];
	[dictionary setObject:self.name forKey:@"name"];
	[dictionary setObject:self.groupID ? self.groupID : @"" forKey:@"groupid"];
	[dictionary setObject:self.description ? self.description : @"" forKey:@"description"];
	[dictionary setObject:@(self.isOpen) forKey:@"is_open"];
	[dictionary setObject:self.ticket ? self.ticket : @"" forKey:@"ticket"];
	[dictionary setObject:self.email forKey:@"user_email"];
	[dictionary setObject:self.firstName forKey:@"user_name"];
	[dictionary setObject:self.lastName forKey:@"user_surname"];
	[dictionary setObject:self.nickname forKey:@"user_nickname"];	
	[dictionary setObject:[self.country dictionaryPresentation] forKey:@"country"];
	[dictionary setObject:[self.city dictionaryPresentation] forKey:@"city"];
	//[dictionary setObject:self.ownerID forKey:@"owner"];
    [dictionary setObject:[self.owner dictionaryPresentation] forKey:@"owner"];
	
	[dictionary setObject:[Base64 encode:UIImagePNGRepresentation([ImageUtils imageWithLowQuality:self.imageFlag])] forKey:@"flag"];
	NSString* color = [Color hexStringWithColor:[UIColor blueColor]];
	[dictionary setObject:color forKey:@"color"];
	return dictionary;
}

-(NSArray*)parseUsers:(NSArray*)array
{
	NSMutableArray* result = [NSMutableArray array];
	User* me = [Model sharedInstance].me;
	for(NSDictionary* userInfo in array)
	{
		User* user = [User userWithDictionary:userInfo];
		[result addObject:[user isEqual:me] ? me :user];
	}
	return result;
}

-(NSArray*)parseUserCoordinates:(NSArray*)array
{
	NSMutableArray* result = [NSMutableArray array];
	for(NSDictionary* info in array)
		[result addObject:[Pin pinWithDictionary:info]];
	
	return result;	
}

-(void)updateUsersWithCriteria:(NSString*)criteria withSuccess:(void(^)())onSuccess onError:(void(^)(NSString* error))onError
{
	[self usersWithCriteria:[TypeUtils radiusString:0] isFullInfo:YES
	withSuccess:^(NSArray *users)
	{
		[self updatePinsForUsersWithSuccess:^
		{
			onSuccess();
		}];
	 }
	onError:^(NSString *error)
	{
		NSLog(@"cannot update users");
		onError(error);
	}];
}

-(void)usersWithCriteria:(NSString*)criteria isFullInfo:(BOOL)fullInfo withSuccess:(void(^)(NSArray* users))onSuccess onError:(void(^)(NSString* error))onError
{
	OnSuccess successBlock = onSuccess;
	OnError errorBlock = onError;
	
	__block BOOL isFullInfo = fullInfo;
	NSString* path = [NSString stringWithFormat:@"groups/%@/users", self.groupID];
	NSDictionary* params = @{@"criteria": criteria, @"fullInfo" : @(fullInfo)};
    
    NSData* data1 = [NSPropertyListSerialization dataFromPropertyList:params format: NSPropertyListBinaryFormat_v1_0 errorDescription:NULL];
    [Model sharedInstance].totalUploadBytes = [data1 length];
    
	[[Model sharedInstance].httpClient postPath:path parameters:params
	success:^(AFHTTPRequestOperation *operation, id responseObject)
	{
        NSDictionary* result = responseObject;
        NSLog(@"%@", result);
        
        NSData* data2 = [NSPropertyListSerialization dataFromPropertyList:result format: NSPropertyListBinaryFormat_v1_0 errorDescription:NULL];
        [Model sharedInstance].totalDownloadBytes = [data2 length];
		
		if(![[result objectForKey:@"success"] boolValue])
		{
			errorBlock([[Model sharedInstance].errorTranslator descriptionForError:[[result objectForKey:@"error"] intValue]]);
			return;
		}
		NSArray* objects = nil;
		if(isFullInfo)
		{
			objects = [self parseUsers:[result objectForKey:@"users"]];
			self.allUsers = [objects mutableCopy];
		}
		else
		{
			objects = [self parseUserCoordinates:[result objectForKey:@"gps"]];
		}
		successBlock(objects);
	}
	failure:^(AFHTTPRequestOperation *operation, NSError *error)
	{
        [Model sharedInstance].totalDownloadBytes = [operation.responseString length];
        
		NSLog(@"params:\n%@", params);
		NSLog(@"%@", operation.responseString);
		errorBlock([error localizedDescription]);
	}];
}

-(void)updatePinsForUsersWithSuccess:(void(^)())onSuccess
{
	[self usersWithCriteria:[TypeUtils radiusString:0] isFullInfo:NO
	withSuccess:^(NSArray* pins)
	{
		for(User* user in self.users)
		{
			for(Pin* pin in pins)
			{
				if([user.userID isEqualToString:pin.userID])
					user.coordinate = pin.coordinate;
			}
		}
		
		//debug
		NSLog(@"[update pins] group: %@", self.name);
		for(User* user in self.users)
			NSLog(@"%@ (%.4f %.4f)", user.nickName, user.coordinate.latitude, user.coordinate.longitude);
		
		NSLog(@"\n\n");
		//debug

		onSuccess();
	}
	onError:^(NSString *error)
	{
		NSLog(@"error occured");
        onSuccess(); //!!! counter pendedUpdatesCount must be decrease
	}];
}

-(void)updateWithSuccess:(void(^)())onSuccess onError:(void (^)(NSString *))onError
{
	OnSuccessSimple successBlock = onSuccess;
	OnError errorBlock = onError;
	
    NSString* path = [NSString stringWithFormat:@"groups/update/"];
    NSDictionary* params = @{@"group": [self dictionaryPresentation]};
    
    NSData* data1 = [NSPropertyListSerialization dataFromPropertyList:params format: NSPropertyListBinaryFormat_v1_0 errorDescription:NULL];
    [Model sharedInstance].totalUploadBytes = [data1 length];
    
	[[Model sharedInstance].httpClient putPath:path parameters:params
	success:^(AFHTTPRequestOperation *operation, id responseObject)
	{
		NSDictionary* result = responseObject;
        
        NSData* data2 = [NSPropertyListSerialization dataFromPropertyList:result format: NSPropertyListBinaryFormat_v1_0 errorDescription:NULL];
        [Model sharedInstance].totalDownloadBytes = [data2 length];
        
		if(![[result objectForKey:@"success"] boolValue])
		{
			NSLog(@"params:\n%@", params);
			NSLog(@"result:\n%@", result);
			errorBlock([[Model sharedInstance].errorTranslator descriptionForError:[[result objectForKey:@"error"] intValue]]);
			return;
		}
		successBlock();
	}
	failure:^(AFHTTPRequestOperation *operation, NSError *error)
	{
        [Model sharedInstance].totalDownloadBytes = [operation.responseString length];
        
		NSLog(@"%@", [error localizedDescription]);
		errorBlock([error localizedDescription]);
	}];
}

-(void)joinWithTicket:(NSString*)ticket onSuccess:(void(^)())onSuccess onError:(void(^)(NSString* error))onError
{
	OnSuccessSimple successBlock = onSuccess;
	OnError errorBlock = onError;
	
	NSString* path = [NSString stringWithFormat:@"groups/%@/join", self.groupID];
    NSDictionary* params = @{@"ticket": ticket};
	NSLog(@"join URL: %@", path);
    NSLog(@"params: %@", params);
    
    NSData* data1 = [NSPropertyListSerialization dataFromPropertyList:params format: NSPropertyListBinaryFormat_v1_0 errorDescription:NULL];
    [Model sharedInstance].totalUploadBytes = [data1 length];
    
	[[Model sharedInstance].httpClient postPath:path parameters:params
	success:^(AFHTTPRequestOperation *operation, id responseObject)
	{
		NSDictionary* result = responseObject;
        
        NSData* data2 = [NSPropertyListSerialization dataFromPropertyList:result format: NSPropertyListBinaryFormat_v1_0 errorDescription:NULL];
        [Model sharedInstance].totalDownloadBytes = [data2 length];
        
        NSLog(@"result: %@", result);
		if(![[result objectForKey:@"success"] boolValue])
		{
			NSString* description = [[Model sharedInstance].errorTranslator descriptionForError:[[result objectForKey:@"error"] intValue]];
			[[Model sharedInstance].me updatePinIsActive:YES];
			errorBlock(description);
			return;
		}
		successBlock();
	}
	failure:^(AFHTTPRequestOperation *operation, NSError *error)
	{
        [Model sharedInstance].totalDownloadBytes = [operation.responseString length];
        
		NSLog(@"%@", [error localizedDescription]);
		errorBlock([error localizedDescription]);
	}];
}

-(void)leaveWithSuccess:(void(^)())onSuccess onError:(void(^)(NSString* error))onError
{
	OnSuccessSimple successBlock = onSuccess;
	OnError errorBlock = onError;
	
	NSString* path = [NSString stringWithFormat:@"groups/%@/leave", self.groupID];
	[[Model sharedInstance].httpClient getPath:path parameters:nil
	success:^(AFHTTPRequestOperation *operation, id responseObject)
	{
		NSDictionary* result = responseObject;
        
        NSData* data2 = [NSPropertyListSerialization dataFromPropertyList:result format: NSPropertyListBinaryFormat_v1_0 errorDescription:NULL];
        [Model sharedInstance].totalDownloadBytes = [data2 length];
        
		if(![[result objectForKey:@"success"] boolValue])
		{
			NSString* description = [[Model sharedInstance].errorTranslator descriptionForError:[[result objectForKey:@"error"] intValue]];
			[[Model sharedInstance].me updatePinIsActive:NO];
			errorBlock(description);
			return;
		}
		[Model sharedInstance].updateManager.activeGroup = nil;
		[[Model sharedInstance].me updatePinIsActive:NO];
		[[Model sharedInstance].updateManager pingIsActive:NO frequency:[Model sharedInstance].settings.requestsFrequency];
		successBlock();
	}
	failure:^(AFHTTPRequestOperation *operation, NSError *error)
	{
        [Model sharedInstance].totalDownloadBytes = [operation.responseString length];
        
		NSLog(@"%@", [error localizedDescription]);
		[[Model sharedInstance].me updatePinIsActive:NO];
		errorBlock([error localizedDescription]);
	}];
}

-(void)sendMessage:(TrackerMessage*)message toUsers:(NSArray*)toUsers onSuccess:(void(^)())onSuccess onError:(void(^)(NSString* error))onError
{
	OnSuccessSimple successBlock = onSuccess;
	OnError errorBlock = onError;
	
	NSMutableArray* users = [NSMutableArray array];
	for(User* user in toUsers)
		[users addObject:user.userID];
	
	NSString* path = [NSString stringWithFormat:@"groups/%@/message", self.groupID];
	NSDictionary* params = @{@"message": [message dictionaryPresentation], @"users" : users};
    
    NSData* data1 = [NSPropertyListSerialization dataFromPropertyList:params format: NSPropertyListBinaryFormat_v1_0 errorDescription:NULL];
    [Model sharedInstance].totalUploadBytes = [data1 length];
    
	[[Model sharedInstance].httpClient postPath:path parameters:params
	success:^(AFHTTPRequestOperation *operation, id responseObject)
	{
		NSDictionary* result = responseObject;
        
        NSData* data2 = [NSPropertyListSerialization dataFromPropertyList:result format: NSPropertyListBinaryFormat_v1_0 errorDescription:NULL];
        [Model sharedInstance].totalDownloadBytes = [data2 length];
        
		if(![[result objectForKey:@"success"] boolValue])
		{
			NSString* description = [[Model sharedInstance].errorTranslator descriptionForError:[[result objectForKey:@"error"] intValue]];
			errorBlock(description);
			return;
		}
		successBlock();
	}
	failure:^(AFHTTPRequestOperation *operation, NSError *error)
	{
        [Model sharedInstance].totalDownloadBytes = [operation.responseString length];
        
		NSLog(@"%@", [error localizedDescription]);
		errorBlock([error localizedDescription]);
	}];
}

-(NSArray*)filterUsersWithCriteria:(NSString*)criteria
{
	NSPredicate* predicate = [NSPredicate predicateWithFormat:
							  @"(firstName contains[c] %@) OR "
							  "(lastName contains[c] %@) OR "
							  "(nickName contains[c] %@) OR "
							  "(email contains[c] %@) OR "
							  "(phoneNumber contains[c] %@)"
							  , criteria, criteria, criteria, criteria, criteria, nil];
	return [self.users filteredArrayUsingPredicate:predicate];
}

-(void)addUsers:(NSArray*)users
{
	for(User* user in users)
	{
		if([self.allUsers containsObject:user])
			continue;
		
		[self.allUsers addObject:user];
	}
}

-(NSArray*)removeUsers:(NSArray*)usersIDs
{
	NSMutableArray* forRemove = [NSMutableArray array];
	for(User* user in self.users)
	{
		for(NSString* userID in usersIDs)
		{
			if([userID isEqualToString:user.userID])
				[forRemove addObject:user];
		}
	}
	[self.allUsers removeObjectsInArray:forRemove];
	return forRemove;
}

- (User*) userWithUserId:(NSString*)userId
{
    for (User* user in self.users)
    {
        if([userId isEqualToString:user.userID])
        {
            return user;
        }
    }
    
    return nil;
}

-(void)encodeWithCoder:(NSCoder *)aCoder
{
	[aCoder encodeObject:[self dictionaryPresentation]];
}

- (id)initWithCoder:(NSCoder *)aDecoder
{
	if(self = [self initWithDictionary:[aDecoder decodeObject] isLocally:YES])
	{}
	return self;
}

@end
