//
//  Group.h
//  GPSTracker
//
//  Created by YS on 1/8/13.
//  Copyright (c) 2013 Yury Shubin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "User.h"
#import "Color.h"
#import "TrackerMessage.h"

@class Country;
@class City;

@interface Group : NSObject<NSCoding>
{}

@property(nonatomic, readonly) NSString* groupID;
@property(nonatomic) NSString* name;
@property(nonatomic) NSString* description;
@property(nonatomic) Country* country;
@property(nonatomic) City* city;
@property(nonatomic, readonly) BOOL isOwner;
@property(nonatomic) BOOL isOpen;
@property(nonatomic) UIColor* color;
@property(nonatomic) UIImage* imageFlag;
@property(nonatomic) NSString* email;
@property(nonatomic) NSString* firstName;
@property(nonatomic) NSString* lastName;
@property(nonatomic) NSString* nickname;
@property(nonatomic) NSArray* users;

@property(nonatomic, retain) User* owner;

+(Group*)groupWithName:(NSString*)name description:(NSString*)description country:(Country*)country city:(City*)city
				 owner:(User*)owner isOpen:(BOOL)isOpen color:(UIColor*)color;
+(Group*)groupWithDictionary:(NSDictionary*)dictionary;
-(NSDictionary*)dictionaryPresentation;

-(void)updateUsersWithCriteria:(NSString*)criteria withSuccess:(void(^)())onSuccess
					   onError:(void(^)(NSString* error))onError;
-(void)updatePinsForUsersWithSuccess:(void(^)())onSuccess;

-(void)joinWithTicket:(NSString*)ticket onSuccess:(void(^)())onSuccess onError:(void(^)(NSString* error))onError;
-(void)leaveWithSuccess:(void(^)())onSuccess onError:(void(^)(NSString* error))onError;
-(void)sendMessage:(TrackerMessage*)message toUsers:(NSArray*)toUsers onSuccess:(void(^)())onSuccess onError:(void(^)(NSString* error))onError;
-(void)updateWithSuccess:(void(^)())onSuccess onError:(void (^)(NSString *))onError;
-(NSArray*)filterUsersWithCriteria:(NSString*)criteria;
-(void)addUsers:(NSArray*)users;
-(NSArray*)removeUsers:(NSArray*)usersIDs;
-(User*)userWithUserId:(NSString*)userId;

@end
