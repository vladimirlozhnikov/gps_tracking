//
//  Country.m
//  GPSTracker
//
//  Created by YS on 2/27/13.
//  Copyright (c) 2013 Yury Shubin. All rights reserved.
//

#import "Country.h"

@interface Country()

@property(nonatomic) NSUInteger countryID;
@property(nonatomic) NSString* description;

@end

@implementation Country

+(Country*)countryWithDictionary:(NSDictionary*)dictionary
{
	Country* country = [Country new];
	country.countryID = [[dictionary objectForKey:@"country_id"] intValue];
	country.description = [dictionary objectForKey:@"name"];
	return country;
}

-(NSDictionary*)dictionaryPresentation
{
	NSMutableDictionary* dictionary = [NSMutableDictionary dictionary];
	[dictionary setObject:@(self.countryID) forKey:@"country_id"];
	[dictionary setObject:self.description forKey:@"name"];	
	return dictionary;
}

@end
