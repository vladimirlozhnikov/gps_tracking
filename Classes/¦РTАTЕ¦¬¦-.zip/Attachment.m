//
//  Attachment.m
//  GPSTracker
//
//  Created by YS on 3/17/13.
//  Copyright (c) 2013 Yury Shubin. All rights reserved.
//

#import "Attachment.h"
#import "Base64.h"
#import "Model.h"

@interface Attachment()

@property(nonatomic) NSData* data;
@property(nonatomic) AttachmentType type;

@end

@implementation Attachment
@synthesize imageUrl, image;

-(id)initWithDictionary:(NSDictionary*)dictionary
{
	if(self = [super init])
	{
//        NSLog(@"%@", dictionary);
		NSString* dataString = [dictionary objectForKey:@"data"];
        self.imageUrl = dataString;
		//!!! self.data = [dataString length] ? [Base64 decode:dataString] : nil;
		self.type = [[dictionary objectForKey:@"type"] intValue] + 1;
	}
	return self;
}

+(Attachment*)attachmentWithDictionary:(NSDictionary*)dictionary
{
	return [[Attachment alloc] initWithDictionary:dictionary];
}

+(Attachment*)attachmentWithImage:(UIImage*)image
{
	Attachment* attachment = [Attachment new];
	attachment.data = UIImagePNGRepresentation(image);
	attachment.type = AttachmentTypeImage;
	return attachment;
}

-(NSDictionary*)attachmentToDictionary
{
	NSMutableDictionary* dictionary = [NSMutableDictionary dictionary];
	[dictionary setObject:@(self.type - 1) forKey:@"type"];
    
	if(self.data)
		[dictionary setObject:[Base64 encode:self.data] forKey:@"data"];
	else
		[dictionary setObject:@"" forKey:@"data"];
	
	return dictionary;
}

-(BOOL)isEmpty
{
	return self.type == AttachmentTypeNone;
}

-(UIImage*)image
{
	if(self.type == AttachmentTypeImage && self.data)
		return [UIImage imageWithData:self.data];
	
	return nil;
}

-(void)encodeWithCoder:(NSCoder *)aCoder
{
	[aCoder encodeObject:[self attachmentToDictionary]];
}

- (id)initWithCoder:(NSCoder *)aDecoder
{
	if(self = [self initWithDictionary:[aDecoder decodeObject]])
	{}
	return self;
}

#pragma mark - Properties

- (void) imageLoadDidFinish:(UIImageView*)imageView
{
    imageView.image = image;
}

- (void) loadImage:(UIImageView*)imageView
{
    NSData* imageData = [NSData dataWithContentsOfURL:[NSURL URLWithString:imageUrl]];
    self.image = [UIImage imageWithData:imageData];
    
    [Model sharedInstance].totalDownloadBytes = [imageData length];
    
    [self performSelectorOnMainThread:@selector(imageLoadDidFinish:) withObject:imageView waitUntilDone:NO];
}

- (void) imageInBackground:(UIImageView*)imageView
{
    if (image)
    {
        imageView.image = image;
    }
    else if ([imageUrl length] > 0)
    {
        NSLog(@"imageUrl: %@", imageUrl);
        [self performSelectorInBackground:@selector(loadImage:) withObject:imageView];
    }
}

@end
