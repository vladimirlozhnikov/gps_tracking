//
//  User.h
//  GPSTracker
//
//  Created by YS on 1/11/13.
//  Copyright (c) 2013 Yury Shubin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>
#import "UpdateInfo.h"
#import "Types.h"

@class TrackerMessage;

@interface User : NSObject
{
    NSString* imageUrl;
    UIImage* imageAvatar;

    CLLocationDegrees lastLatitude;
	CLLocationDegrees lastLongitude;
}

@property(nonatomic, strong) NSString* firstName;
@property(nonatomic, strong) NSString* lastName;
@property(nonatomic, strong) NSString* nickName;
@property(nonatomic, strong) NSString* email;
@property(nonatomic, strong) NSString* phoneNumber;
@property (nonatomic, retain) NSString* imageUrl;
@property(nonatomic, retain) UIImage* imageAvatar;
@property(nonatomic, readonly) NSString* userID;
@property(nonatomic) CLLocationCoordinate2D coordinate;
@property(nonatomic, readonly) UpdateInfo* updateInfo;
@property(nonatomic) BOOL backgroundModeActive;
@property(nonatomic, copy) void(^onUpdateCoordinatesBlock)();

+(User*)userWithDictionary:(NSDictionary*)dictionary;
+(User*)userWithFirstName:(NSString*)firstName lastName:(NSString*)lastName email:(NSString*)email;
-(void)registerWithSuccess:(void(^)(void))onSuccess onError:(void(^)(NSString* error))onError;
-(void)updateWithSuccess:(void(^)(void))onSuccess onError:(void(^)(NSString* error))onError;
-(void)abuseWithSuccess:(void(^)(void))onSuccess onError:(void(^)(NSString* error))onError;
-(NSDictionary*)dictionaryPresentation;

- (NSString*)distanceFromLocation:(CLLocation*)fromLocation kmHOnly:(BOOL)kmHOnly;

-(void)updatePinIsActive:(BOOL)active;
- (void) imageInBackground:(UIImageView*)imageView;

@end
