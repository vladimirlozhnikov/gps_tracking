//
//  Message.m
//  GPSTracker
//
//  Created by YS on 1/20/13.
//  Copyright (c) 2013 Yury Shubin. All rights reserved.
//

#import "TrackerMessage.h"
#import "User.h"
#import "Base64.h"
#import "DateUtils.h"

@interface TrackerMessage()

@property(nonatomic) NSString* userID;
@property(nonatomic) User* user;
@property(nonatomic) NSString* text;
@property(nonatomic) MessagePriority priority;
@property(nonatomic) NSDate* dateTime;
@property(nonatomic) NSString* messageID;
@property(nonatomic) Attachment* attachment;

@end

@implementation TrackerMessage

+(TrackerMessage*)messageWithText:(NSString*)text image:(UIImage*)image priority:(MessagePriority)priority user:(User*)user
{
	TrackerMessage* message = [TrackerMessage new];
    message.from = user;
	message.text = text;
	message.attachment = [Attachment attachmentWithImage:image];
	message.priority = priority;
	return message;
}

-(id)initWithDictionary:(NSDictionary*)dictionary
{
	if(self = [super init])
	{
		self.messageID = [dictionary objectForKey:@"id"];
		self.text = [dictionary objectForKey:@"text"];
		self.attachment = [Attachment attachmentWithDictionary:[dictionary objectForKey:@"attachment"]];
		self.priority = [[dictionary objectForKey:@"flag"] intValue];
        self.from = [User userWithDictionary:[dictionary objectForKey:@"from"]];
		self.dateTime = [DateUtils dateFromUnixString:[dictionary objectForKey:@"time"]];
		
		NSString* isUnread = [dictionary objectForKey:@"isUnread"];
		self.isUnread = [isUnread boolValue];
	}
	return self;
}

+(TrackerMessage*)messageWithDictionary:(NSDictionary*)dictionary
{
	return [[TrackerMessage alloc] initWithDictionary:dictionary];
}

-(NSDictionary*)dictionaryPresentation
{
	NSMutableDictionary* dictionary = [NSMutableDictionary dictionary];
	[dictionary setObject:[self.messageID length] > 0 ? self.messageID : @"" forKey:@"id"];
	[dictionary setObject:self.text forKey:@"text"];
	[dictionary setObject:[self.attachment attachmentToDictionary] forKey:@"attachment"];
	[dictionary setObject:@(self.priority) forKey:@"flag"];
	[dictionary setObject:[self.from dictionaryPresentation] forKey:@"from"];
	[dictionary setObject:[NSString stringWithFormat:@"%d", self.isUnread] forKey:@"isUnread"];
	
	if(self.dateTime)
		[dictionary setObject:[DateUtils UnixStringFromDate:self.dateTime] forKey:@"time"];
	else
		[dictionary setObject:@"" forKey:@"time"];
	
	NSLog(@"message save: %@", self.messageID);
	return dictionary;
}

-(NSString*)date
{
	return [DateUtils stringFromDate:self.dateTime];
}

-(void)encodeWithCoder:(NSCoder *)aCoder
{
	[aCoder encodeObject:[self dictionaryPresentation]];
}

- (id)initWithCoder:(NSCoder *)aDecoder
{
	if(self = [self initWithDictionary:[aDecoder decodeObject]])
	{}
	return self;
}

-(BOOL)isEqual:(TrackerMessage*)object
{
	return [self.messageID isEqualToString:object.messageID];
}

@end
