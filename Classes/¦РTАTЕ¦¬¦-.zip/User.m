//
//  User.m
//  GPSTracker
//
//  Created by YS on 1/11/13.
//  Copyright (c) 2013 Yury Shubin. All rights reserved.
//

#import "User.h"
#import "Model.h"
#import "Base64.h"
#import "Pin.h"
#import "FileUtils.h"
#import "Types.h"
#import "ImageUtils.h"

@interface User()

@property(nonatomic, strong) NSString* userID;
@property(nonatomic) NSUInteger status;
@property(nonatomic) NSTimer* pinTimer;
@property(nonatomic) BOOL isUpdatePinActive;
@property(nonatomic) BOOL isBusy;
@property(nonatomic) BOOL previousValue;

@end

@implementation User
@synthesize imageUrl, imageAvatar;

typedef void(^OnSuccessArray)(NSArray* array);
typedef void(^OnSuccess)(void);
typedef void(^OnError)(NSString* error);

-(id)init
{
	if(self = [super init])
	{
		self.coordinate = kCLLocationCoordinate2DInvalid;
		self.phoneNumber = @"";
		self.userID = @"";
	}
	return self;
}

-(void)dealloc
{
	[self.pinTimer invalidate];
	self.pinTimer = nil;
}

-(BOOL)isEqual:(User*)object
{
	return [self.userID isEqualToString:object.userID];
}

+(User*)userWithDictionary:(NSDictionary*)dictionary
{
	User* user = [User new];	
	user.nickName = [dictionary objectForKey:@"nickname"];
	user.phoneNumber = [dictionary objectForKey:@"phonenumber"];
	user.userID = [dictionary objectForKey:@"userid"];
	
//    NSLog(@"%@", dictionary);
	NSString* avatar = [dictionary objectForKey:@"avatar"];
	if (avatar != (NSString*)[NSNull null])
    {
        user.imageUrl = avatar;
    }
	//!!!	user.imageAvatar = [UIImage imageWithData:[Base64 decode:avatar]];
		
	user.email = [dictionary objectForKey:@"email"];
	user.lastName = [dictionary objectForKey:@"surname"];
	user.firstName = [dictionary objectForKey:@"username"];
	user.status	= [[dictionary objectForKey:@"status"] intValue];
	return user;
}

-(NSDictionary*)dictionaryPresentation
{
	NSMutableDictionary* dictionary = [NSMutableDictionary dictionary];
    NSMutableDictionary* userDictionary = [NSMutableDictionary dictionary];
    [dictionary setObject:userDictionary forKey:@"user"];
    
	[userDictionary setObject:self.nickName forKey:@"nickname"];
	[userDictionary setObject:self.phoneNumber forKey:@"phonenumber"];
	[userDictionary setObject:self.userID forKey:@"userid"];
	
	if (self.imageAvatar)
		[userDictionary setObject:[Base64 encode:UIImagePNGRepresentation([ImageUtils imageWithLowQuality:self.imageAvatar])] forKey:@"avatar"];
	else
		[userDictionary setObject:@"" forKey:@"avatar"];
	
	[userDictionary setObject:self.email forKey:@"email"];
	[userDictionary setObject:self.lastName forKey:@"surname"];
	[userDictionary setObject:@(self.status) forKey:@"status"];
	[userDictionary setObject:self.firstName forKey:@"username"];
	return dictionary;
}

+(User*)userWithFirstName:(NSString*)firstName lastName:(NSString*)lastName email:(NSString*)email
{
	User* user = [User new];
	user->_firstName = firstName;
	user->_lastName = lastName;
	user->_email = email;
	return user;
}

-(void)registerWithSuccess:(void(^)(void))onSuccess onError:(void(^)(NSString* error))onError
{
	__block OnSuccess successBlock = onSuccess;
	__block OnError errorBlock = onError;
	
	NSDictionary* params = [self dictionaryPresentation];
    
    NSData* data1 = [NSPropertyListSerialization dataFromPropertyList:params format: NSPropertyListBinaryFormat_v1_0 errorDescription:NULL];
    [Model sharedInstance].totalUploadBytes = [data1 length];
    
	[[Model sharedInstance].httpClient postPath:@"users/register" parameters:params
	success:^(AFHTTPRequestOperation *operation, id responseObject)
	{
		NSDictionary* result = responseObject;
        
        NSData* data2 = [NSPropertyListSerialization dataFromPropertyList:result format: NSPropertyListBinaryFormat_v1_0 errorDescription:NULL];
        [Model sharedInstance].totalDownloadBytes = [data2 length];
        
		if(![[result objectForKey:@"success"] boolValue])
		{
			NSLog(@"params:\n%@", params);
			NSLog(@"result:\n%@", result);
			errorBlock([[Model sharedInstance].errorTranslator descriptionForError:[[result objectForKey:@"error"] intValue]]);
			return;
		}
		[Model sharedInstance].credentials.username = self.email;
		[Model sharedInstance].credentials.password = [result objectForKey:@"password"];
		[[Model sharedInstance].credentials save];
		successBlock();
	}
	failure:^(AFHTTPRequestOperation *operation, NSError *error)
	{
        [Model sharedInstance].totalDownloadBytes = [operation.responseString length];
        
		NSLog(@"params:\n%@", params);
		NSLog(@"%@", operation.responseString);
		errorBlock([error localizedDescription]);
	}];
}

-(void)updateWithSuccess:(void(^)(void))onSuccess onError:(void(^)(NSString* error))onError
{
	__block OnSuccess successBlock = onSuccess;
	__block OnError errorBlock = onError;
	
	NSString* path = [NSString stringWithFormat:@"users/update/%@", self.userID];
    NSDictionary* params = [self dictionaryPresentation];
    
    NSData* data1 = [NSPropertyListSerialization dataFromPropertyList:params format: NSPropertyListBinaryFormat_v1_0 errorDescription:NULL];
    [Model sharedInstance].totalUploadBytes = [data1 length];
    
	[[Model sharedInstance].httpClient postPath:path parameters:params
										success:^(AFHTTPRequestOperation *operation, id responseObject)
	{
		NSDictionary* result = responseObject;
        
        NSData* data2 = [NSPropertyListSerialization dataFromPropertyList:result format: NSPropertyListBinaryFormat_v1_0 errorDescription:NULL];
        [Model sharedInstance].totalDownloadBytes = [data2 length];
        
		if(![[result objectForKey:@"success"] boolValue])
		{
			NSLog(@"result:\n%@", result);
			errorBlock([[Model sharedInstance].errorTranslator descriptionForError:[[result objectForKey:@"error"] intValue]]);
			return;
		}
		successBlock();
	}
	failure:^(AFHTTPRequestOperation *operation, NSError *error)
	{
        [Model sharedInstance].totalDownloadBytes = [operation.responseString length];
        
		NSLog(@"%@", operation.responseString);
		errorBlock([error localizedDescription]);
	}];
}

-(void)abuseWithSuccess:(void(^)(void))onSuccess onError:(void(^)(NSString* error))onError
{
	__block OnSuccess successBlock = onSuccess;
	__block OnError errorBlock = onError;
	
	NSString* path = [NSString stringWithFormat:@"complain/%@", self.userID];
	[[Model sharedInstance].httpClient getPath:path parameters:nil
	success:^(AFHTTPRequestOperation *operation, id responseObject)
	{
		NSDictionary* result = responseObject;
        
        NSData* data2 = [NSPropertyListSerialization dataFromPropertyList:result format: NSPropertyListBinaryFormat_v1_0 errorDescription:NULL];
        [Model sharedInstance].totalDownloadBytes = [data2 length];
        
		if(![[result objectForKey:@"success"] boolValue])
		{
			NSLog(@"result:\n%@", result);
			errorBlock([[Model sharedInstance].errorTranslator descriptionForError:[[result objectForKey:@"error"] intValue]]);
			return;
		}
		successBlock();
	}
	failure:^(AFHTTPRequestOperation *operation, NSError *error)
	{
        [Model sharedInstance].totalDownloadBytes = [operation.responseString length];
        
		NSLog(@"%@", operation.responseString);
		errorBlock([error localizedDescription]);
	}];
}

-(void)onUpdatePin:(NSTimer*)timer
{
	if(!CLLocationCoordinate2DIsValid(self.coordinate))
		return;
    
    CLLocation* newLocation = [[CLLocation alloc] initWithLatitude:self.coordinate.latitude longitude:self.coordinate.longitude];
    CLLocation* oldLocation = [[CLLocation alloc] initWithLatitude:lastLatitude longitude:lastLongitude];
    
    CLLocationDistance distance = [newLocation distanceFromLocation:oldLocation];
    if (distance < 50)
    {
        return;
    }
    
    lastLatitude = self.coordinate.latitude;
    lastLongitude = self.coordinate.longitude;
	
	Pin* pin = [Pin pinWithCoordinate:self.coordinate userID:self.userID];
	NSString* path = [NSString stringWithFormat:@"update_coordinates"];
	NSDictionary* params = [pin dictionaryPresentation];
    
    NSData* data1 = [NSPropertyListSerialization dataFromPropertyList:params format: NSPropertyListBinaryFormat_v1_0 errorDescription:NULL];
    [Model sharedInstance].totalUploadBytes = [data1 length];
    
	if(self.isBusy)
		return;
	
	self.isBusy = YES;
	[[Model sharedInstance].httpClient postPath:path parameters:params
	success:^(AFHTTPRequestOperation *operation, id responseObject)
	{
		NSDictionary* result = responseObject;
        
        NSData* data2 = [NSPropertyListSerialization dataFromPropertyList:result format: NSPropertyListBinaryFormat_v1_0 errorDescription:NULL];
        [Model sharedInstance].totalDownloadBytes = [data2 length];
        
		if(![[result objectForKey:@"success"] boolValue])
		{
			NSLog(@"result:\n%@", result);
			NSLog(@"%@", [[Model sharedInstance].errorTranslator descriptionForError:[[result objectForKey:@"error"] intValue]]);
			return;
		}
//		NSLog(@"Pin sent");
		self.isBusy = NO;
	}
	failure:^(AFHTTPRequestOperation *operation, NSError *error)
	{
        [Model sharedInstance].totalDownloadBytes = [operation.responseString length];
//		NSLog(@"%@", operation.responseString);
		self.isBusy = NO;
	}];
}

-(void)updatePinIsActive:(BOOL)active
{
	if(active)
	{
		NSInteger timeout = [[Model sharedInstance].settings timeoutForRequestsFrequency];
		if(timeout == -1)
		{
			[self.pinTimer invalidate];
			self.pinTimer = nil;
		}
		else if(!self.pinTimer)
		{
			self.pinTimer = [NSTimer scheduledTimerWithTimeInterval:timeout
															 target:self selector:@selector(onUpdatePin:)
														   userInfo:nil repeats:YES];
			
			[self onUpdatePin:nil];
		}
	}
	else
	{
		[self.pinTimer invalidate];
		self.pinTimer = nil;
	}

	self.isUpdatePinActive = active;
}

-(void)setCoordinate:(CLLocationCoordinate2D)coordinate
{
	if(!CLLocationCoordinate2DIsValid(coordinate))
		return;
	
	_coordinate = coordinate;
	NSInteger timeout = [[Model sharedInstance].settings timeoutForRequestsFrequency];

	if(timeout == -1 && self.isUpdatePinActive)
		[self onUpdatePin:nil];
	
	if(self.onUpdateCoordinatesBlock)
		self.onUpdateCoordinatesBlock();
}

-(void)setBackgroundModeActive:(BOOL)backgroundModeActive
{
	if(_backgroundModeActive == backgroundModeActive)
		return;
	
	NSLog(@"user: background %d", backgroundModeActive);
	_backgroundModeActive = backgroundModeActive;
	if(_backgroundModeActive)
	{
		self.previousValue = self.isUpdatePinActive;
		if(self.previousValue)
		{
			[self updatePinIsActive:NO];
			[self updatePinIsActive:YES];
		}
	}
	else
	{
		if(self.previousValue)
		{
			[self updatePinIsActive:NO];
			[self updatePinIsActive:YES];
		}
	}
}

- (NSString*)distanceFromLocation:(CLLocation*)fromLocation kmHOnly:(BOOL)kmHOnly
{
	NSString* distanceString = nil;
	CLLocation* location = [[CLLocation alloc] initWithLatitude:self.coordinate.latitude longitude:self.coordinate.longitude];
	CLLocationDistance distance = [fromLocation distanceFromLocation:location];
	if(distance < 1000.f && !kmHOnly)
		distanceString = [NSString stringWithFormat:@"%.1f meters", distance];
	else
		distanceString = [NSString stringWithFormat:@"%.1f kilometers", distance / 1000.f];
	
	return distanceString;
}

#pragma mark - Properties

/*- (UIImage*) imageAvatar
{
    return imageAvatar;
}*/

- (void) imageLoadDidFinish:(UIImageView*)imageView
{
    imageView.image = imageAvatar;
    imageView.hidden = NO;
}

- (void) loadImage:(UIImageView*)imageView
{
    NSData* imageData = [NSData dataWithContentsOfURL:[NSURL URLWithString:imageUrl]];
    self.imageAvatar = [UIImage imageWithData:imageData];
    
    [Model sharedInstance].totalDownloadBytes = [imageData length];
    
    [self performSelectorOnMainThread:@selector(imageLoadDidFinish:) withObject:imageView waitUntilDone:NO];
}

- (void) imageInBackground:(UIImageView*)imageView
{
    if (imageAvatar)
    {
        imageView.image = imageAvatar;
        imageView.hidden = NO;
    }
    else if ([imageUrl length] > 0)
    {
        [self performSelectorInBackground:@selector(loadImage:) withObject:imageView];
    }
}

@end
