//
//  City.m
//  GPSTracker
//
//  Created by YS on 2/27/13.
//  Copyright (c) 2013 Yury Shubin. All rights reserved.
//

#import "City.h"

@interface City()

@property(nonatomic) NSUInteger cityID;
@property(nonatomic) NSString* description;

@end

@implementation City

+(City*)cityWithDictionary:(NSDictionary*)dictionary
{
	City* city = [City new];
	city.cityID = [[dictionary objectForKey:@"city_id"] intValue];
	city.description = [dictionary objectForKey:@"name"];
	return city;
}

-(NSDictionary*)dictionaryPresentation
{
	return @{@"city_id" : @(self.cityID), @"name" : self.description};
}

@end