//
//  Attachment.h
//  GPSTracker
//
//  Created by YS on 3/17/13.
//  Copyright (c) 2013 Yury Shubin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Types.h"

@interface Attachment : NSObject<NSCoding>
{
    NSString* imageUrl;
}

@property(nonatomic, readonly) NSData* data;
@property(nonatomic, readonly) AttachmentType type;
@property(nonatomic, readonly) BOOL isEmpty;
@property(nonatomic, retain) UIImage* image;
@property(nonatomic, retain) NSString* imageUrl;

+(Attachment*)attachmentWithImage:(UIImage*)image;
+(Attachment*)attachmentWithDictionary:(NSDictionary*)dictionary;
-(NSDictionary*)attachmentToDictionary;

- (void) imageInBackground:(UIImageView*)imageView;

@end
