//
//  Country.h
//  GPSTracker
//
//  Created by YS on 2/27/13.
//  Copyright (c) 2013 Yury Shubin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Country : NSObject

@property(nonatomic, readonly) NSString* description;
@property(nonatomic, readonly) NSUInteger countryID;

+(Country*)countryWithDictionary:(NSDictionary*)dictionary;
-(NSDictionary*)dictionaryPresentation;

@end
